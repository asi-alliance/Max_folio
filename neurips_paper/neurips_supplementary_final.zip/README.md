# Supplementary Materials: Iter — Formally Verified Epistemic Self-Monitoring for Self-Improving Agents

## Contents

### source/
- neurips_paper.tex — Main paper LaTeX source
- neurips_paper.bib — Bibliography
- neurips_2026.sty — NeurIPS 2026 style file

### lean_files/
40 Lean 4 files (v4.30.0, no Mathlib required). All compile clean with 0 sorry, 40 axiom-free.

Categories:
- Architecture (16 files): HeartModel, ClawArchitectures, PresentMoment, IterArchitecture, ProtectedPlasticity, EvilAI, IterCoreProperties, IterLoopInvariants, IterToolLifecycle, IterBootAndRestart, IterSelfModification, IterSelfModificationReach, IterTransformationPipeline, IterSafetyProperties, IterExperienceManagement, IterChannelSystem
- NAL Inference (8 files): NALRevision, NALDeduction, NALAbductionInduction, NALAnalogy, NALNegation, NALConditional, NALAntiGoal, PLNTruthFunctions
- Impossibility (6 files): NALNonAssociativity, NALHopfImpossibility, NALPreLie, NALCStarImpossibility, NALSymplecticImpossibility, NALLeibnizImpossibility
- Confabulation Gate (1 file): ConfabulationGate
- PLN (2 files): PLNTruthFunctions, PLNChainDepthPenalty
- NAL Convergence (6 files): NALConvergence, NALLyapunov, NALContraction, NALContractionMetric, NALTruthMonotonicity, NALMultiAgentAgreement
- NAL Temporal (1 file): NAL7Temporal

Total: 596 theorems/examples across 40 files, 0 sorry, 40 axiom-free.

## Compilation
```
lake build
```
Or compile individual files:
```
lean <filename>.lean
```
37 of 40 files compile standalone with `lean <file>`. 3 files (EvilAI.lean, IterArchitecture.lean, ProtectedPlasticity.lean) use `import` statements and require `lake build`. A `lakefile.toml` is included.
