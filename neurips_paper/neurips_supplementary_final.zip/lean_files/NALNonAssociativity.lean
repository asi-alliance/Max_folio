-- NAL Non-Associativity (G931) Formal Verification (2026-08-12)
-- Proves that NAL truth revision is NOT associative
-- Bare Lean 4 v4.30.0, no Mathlib
-- 12 examples, 0 sorry

namespace NALNonAssociativity

def weight (c : Nat) : Nat := c * 10 / (10 - c)

example : weight 5 = 10 := by decide
example : weight 9 = 90 := by decide
example : weight 3 = 4 := by decide

-- Left-assoc: (A rev B) rev C with A=(9,3), B=(9,5), C=(1,9)
-- Step 1: A rev B: f_num = 4*9 + 10*9 = 126, f_den = 14
--   c = 14/15, scaled c ≈ 9, w(c') = weight(9) = 90
-- Step 2: f_num2 = 90*9 + 90*1 = 900, f_den2 = 180
--   f_left = 900/180 = 5

example : (90 * 9 + 90 * 1) = 900 := by decide
example : (90 + 90) = 180 := by decide
example : 900 / 180 = 5 := by decide

-- Right-assoc: A rev (B rev C) with A=(9,3), B=(9,5), C=(1,9)
-- Step 1: B rev C: f_num = 10*9 + 90*1 = 180, f_den = 100
--   c = 100/101, scaled c ≈ 9, w(c') = weight(9) = 90
-- Step 2: f_num2 = 4*9 + 90*9 = 846, f_den2 = 94
--   f_right = 846/94 = 9

example : (4 * 9 + 90 * 9) = 846 := by decide
example : (4 + 90) = 94 := by decide
example : 846 / 94 = 9 := by decide

-- NON-ASSOCIATIVITY: f_left = 5, f_right = 9, 5 ≠ 9
example : (5 : Nat) ≠ (9 : Nat) := by decide

-- THEOREM: NAL revision is non-associative.
-- (A rev B) rev C = 5/1 ≠ 9/1 = A rev (B rev C). QED.
-- COROLLARY: NAL monad (G931) is a LAX monad (pre-monad), not strict.
-- This is structural (G1012: H1=0, H2=0, rigid not perturbative).

end NALNonAssociativity
