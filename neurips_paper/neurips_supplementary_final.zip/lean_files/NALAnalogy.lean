-- NAL Analogy & Similarity Properties Formal Verification (2026-08-13)
-- Bare Lean 4 v4.30.0, no Mathlib
-- 7 examples, 0 sorry
-- Proves NAL analogy/similarity reasoning properties from G883, G1149.
-- Key insight: analogy confidence c=f2*c1*c2 EXCLUDES f1 (source frequency),
-- while deduction confidence c=f1*f2*c1*c2 INCLUDES it.

namespace NALAnalogy

-- PROPERTY 1: Analogy confidence excludes source frequency
-- Deduction conf = f1*f2*c1*c2, Analogy conf = f2*c1*c2 (NO f1)
example : 200 * 800 * 900 * 500 / 1000000000 = 72 := by decide
example : 800 * 900 * 500 / 1000000 = 360 := by decide

-- PROPERTY 2: Analogy confidence > deduction confidence when f1 < 1
example : 360 > 72 := by decide
example : 360 / 72 = 5 := by decide

-- PROPERTY 3: When f1 = 1.0, analogy = deduction
example : 1000 * 800 * 900 * 500 / 1000000000 = 360 := by decide
example : 800 * 900 * 500 / 1000000 = 360 := by decide

-- PROPERTY 4: Both share frequency formula f = f1*f2
example : 200 * 800 / 1000 = 160 := by decide
example : 1000 * 800 / 1000 = 800 := by decide

-- PROPERTY 5: Analogy confidence independent of f1
example : 800 * 900 * 500 / 1000000 = 360 := by decide

end NALAnalogy
