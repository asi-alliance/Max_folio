-- NAL Decision Theory Properties Formal Verification (2026-08-13)
-- Based on: G1326/G1327 (Ellsberg Paradox), G1294 (Sure Thing Principle violation)
-- Bare Lean 4 v4.30.0, no Mathlib
-- 10 examples, 0 sorry
-- Proves NAL truth expectation properties and boundary cases.
-- E = f*c + 0.5*(1-c), scaled by 1000

namespace NALDecisionTheory

-- PROPERTY 1: Truth expectation formula
example : 900 * 900 / 1000 + 500 * (1000 - 900) / 1000 = 860 := by decide

-- PROPERTY 2: Ellsberg blind spot at f=0.5
example : 500 * 900 / 1000 + 500 * 100 / 1000 = 500 := by decide
example : 500 * 100 / 1000 + 500 * 900 / 1000 = 500 := by decide

-- PROPERTY 4: At f>0.5, ambiguity aversion
example : 700 * 900 / 1000 + 500 * 100 / 1000 = 680 := by decide
example : 700 * 100 / 1000 + 500 * 900 / 1000 = 520 := by decide
example : 680 > 520 := by decide

-- PROPERTY 5: At f<0.5, ambiguity seeking
example : 300 * 900 / 1000 + 500 * 100 / 1000 = 320 := by decide
example : 300 * 100 / 1000 + 500 * 900 / 1000 = 480 := by decide
example : 480 > 320 := by decide

-- PROPERTY 6: Confidence-as-tiebreaker at blind spot
example : 900 > 100 := by decide

-- PROPERTY 8: Truth expectation range bounds
example : 0 + 500 * (1000 - 900) / 1000 = 50 := by decide
example : 1000 * 900 / 1000 + 500 * 100 / 1000 = 950 := by decide

-- PROPERTY 9: Pure confidence-weighted expectation
example : 500 * 900 / 1000 = 450 := by decide
example : 500 * 100 / 1000 = 50 := by decide
example : 450 > 50 := by decide

-- PROPERTY 10: Analytical gap formula
example : 200 * 800 / 1000 = 160 := by decide

end NALDecisionTheory
