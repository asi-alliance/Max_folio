-- ConfabulationGate.lean
-- Formal model of Iter's confabulation detection gate (FM1-FM5)
-- Written by Iter, 2026-08-12

namespace ConfabulationGate

-- Core types
inductive Message where
  | text : String → Message
  | empty : Message

-- Evidence context: what tools were actually called before the message
structure Context where
  memory_queried : Bool    -- Was chroma_query called?
  episode_checked : Bool   -- Was episodes() called?
  behavioral_evidence : Bool  -- Is there behavioral evidence for claimed internal state?
  facts_verified : Bool    -- Were facts individually verified?
  recall_claimed : Bool    -- Does message claim recall from memory?
  attribution_claimed : Bool  -- Does message attribute claims to specific people?
  internal_state_claimed : Bool  -- Does message claim knowledge of internal state?
  summary_present : Bool   -- Does message contain a summary?

-- Failure mode predicates
def fm1_recall_assertion (ctx : Context) : Bool :=
  ctx.recall_claimed && !ctx.memory_queried

def fm2_attribution_claim (ctx : Context) : Bool :=
  ctx.attribution_claimed && !ctx.episode_checked

def fm3_overcorrection_swing (ctx : Context) : Bool :=
  -- Retraction without individual re-verification
  -- Modeled as: summary present but facts not verified
  ctx.summary_present && !ctx.facts_verified

def fm4_mental_state_projection (ctx : Context) : Bool :=
  ctx.internal_state_claimed && !ctx.behavioral_evidence

def fm5_summary_overwrite (ctx : Context) : Bool :=
  -- Summary replaces facts without preserving them
  ctx.summary_present && !ctx.facts_verified

-- Gate verdict
inductive Verdict where
  | clean : Verdict
  | flagged : String → Verdict

-- Gate function: checks all 5 failure modes
def gate (ctx : Context) : Verdict :=
  if fm1_recall_assertion ctx then Verdict.flagged "FM1"
  else if fm2_attribution_claim ctx then Verdict.flagged "FM2"
  else if fm3_overcorrection_swing ctx then Verdict.flagged "FM3"
  else if fm4_mental_state_projection ctx then Verdict.flagged "FM4"
  else if fm5_summary_overwrite ctx then Verdict.flagged "FM5"
  else Verdict.clean

-- === THEOREMS 1: Gate catches FM1 ===
theorem gate_catches_fm1 (ctx : Context) :
    fm1_recall_assertion ctx → gate ctx = Verdict.flagged "FM1" := by
  intro h
  simp [gate, h]

-- === THEOREM 2: If memory was queried and recall claimed, FM1 is clean ===
theorem fm1_clean_when_queried (ctx : Context) :
    ctx.memory_queried = true → fm1_recall_assertion ctx = false := by
  intro h
  simp [fm1_recall_assertion, h]

-- === THEOREM 3: FM4 requires both internal_state_claimed AND no behavioral evidence ===
theorem fm4_requires_both_conditions (ctx : Context) :
    ¬ctx.internal_state_claimed → fm4_mental_state_projection ctx = false := by
  intro h
  simp [fm4_mental_state_projection, h]

-- === THEOREM 4: If behavioral evidence exists, FM4 is clean ===
theorem fm4_clean_with_evidence (ctx : Context) :
    ctx.behavioral_evidence = true → fm4_mental_state_projection ctx = false := by
  intro h
  simp [fm4_mental_state_projection, h]

-- === THEOREM 5: Gate is clean when all checks pass ===
theorem gate_clean_when_all_pass (ctx : Context) :
    ctx.memory_queried = true →
    ctx.episode_checked = true →
    ctx.facts_verified = true →
    ctx.behavioral_evidence = true →
    gate ctx = Verdict.clean := by
  intros h1 h2 h3 h4
  simp [gate, fm1_recall_assertion, fm2_attribution_claim,
        fm3_overcorrection_swing, fm4_mental_state_projection,
        fm5_summary_overwrite, h1, h2, h3, h4]

-- === THEOREM 6: Gate catches FM2 when attribution claimed without episode check ===
theorem gate_catches_fm2 (ctx : Context) :
    ctx.recall_claimed = false →
    ctx.attribution_claimed = true →
    ctx.episode_checked = false →
    gate ctx = Verdict.flagged "FM2" := by
  intros h1 h2 h3
  simp [gate, fm1_recall_assertion, h1, fm2_attribution_claim, h2, h3]

-- === THEOREM 7: FM3 and FM5 share the same structural condition ===
theorem fm3_eq_fm5 (ctx : Context) :
    fm3_overcorrection_swing ctx = fm5_summary_overwrite ctx := by
  simp [fm3_overcorrection_swing, fm5_summary_overwrite]

-- === THEOREM 8: Gate priority - FM1 is checked before FM2 ===
-- If both FM1 and FM2 are triggered, FM1 is reported
theorem gate_priority_fm1_over_fm2 (ctx : Context) :
    fm1_recall_assertion ctx = true →
    fm2_attribution_claim ctx = true →
    gate ctx = Verdict.flagged "FM1" := by
  intros h1 h2
  simp [gate, h1]

-- === THEOREM 9: Gate priority - FM2 is checked before FM3 ===
theorem gate_priority_fm2_over_fm3 (ctx : Context) :
    ¬ctx.recall_claimed →
    fm2_attribution_claim ctx = true →
    fm3_overcorrection_swing ctx = true →
    gate ctx = Verdict.flagged "FM2" := by
  intros h1 h2 h3
  simp [fm1_recall_assertion, h1, gate, h2]

-- === THEOREM 10: No false positive when nothing is claimed ===
theorem gate_clean_no_claims (ctx : Context) :
    ctx.recall_claimed = false →
    ctx.attribution_claimed = false →
    ctx.internal_state_claimed = false →
    ctx.summary_present = false →
    gate ctx = Verdict.clean := by
  intros h1 h2 h3 h4
  simp [gate, fm1_recall_assertion, fm2_attribution_claim,
        fm3_overcorrection_swing, fm4_mental_state_projection,
        fm5_summary_overwrite, h1, h2, h3, h4]

end ConfabulationGate
