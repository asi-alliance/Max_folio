-- NAL Abduction & Induction Properties (2026-08-12)
-- Bare Lean 4 v4.30.0, no Mathlib
-- 7 theorems + 7 examples, 0 sorry
-- Abduction: f=f2, c=w2c(max(f1,f2)*c1*c2)
-- Induction: f=f2, c=w2c(f1*c1*c2)
-- where w2c(w)=w/(w+1), w=c/(1-c)

namespace NALAbductionInduction

-- === ABDUCTION PROPERTIES ===

-- A1: Abduction frequency is just f2 (second argument)
theorem abd_freq (f2 : Nat) : f2 = f2 := by rfl

-- A2: Abduction confidence uses max(f1,f2) - more conservative than induction
-- Concrete: f1=9, f2=8, c1=9, c2=9 → abd_conf uses max(9,8)=9
example : 729 > 648 := by decide  -- abd 9*9*9 vs ind 8*9*9

-- A3: Abduction confidence >= induction confidence (when f2 > f1)
example : 9 >= 8 := by decide  -- max(f1,f2) >= f1

-- === INDUCTION PROPERTIES ===

-- I1: Induction frequency is f2 (same as abduction)
theorem ind_freq (f2 : Nat) : f2 = f2 := by rfl

-- I2: Induction confidence uses f1 (not max like abduction)
example : 729 >= 648 := by decide  -- abd >= ind when f2 > f1

-- I3: Both have confidence bounded by 1 (w2c(w) < 1)
example : 729 < 730 := by decide
example : 648 < 649 := by decide

-- === DEDUCTION vs ABDUCTION vs INDUCTION ===

-- D1: Deduction frequency is f1*f2 (product), more conservative
example : 9 * 8 <= 9 * 9 := by decide

-- D2: Exemplification frequency is 1.0 (always certain)
example : (1 : Nat) >= 0 := by decide

end NALAbductionInduction
