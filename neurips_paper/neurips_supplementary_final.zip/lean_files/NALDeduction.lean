-- NAL Deduction Properties (2026-08-12)
-- Bare Lean 4 v4.30.0, no Mathlib
-- 7 theorems + 4 examples, 0 sorry

namespace NALDeduction

-- Property 1: Deduction frequency is product of input frequencies
-- f_out = f1 * f2 (symmetric in f1, f2)
theorem ded_freq_symm (f1 f2 : Nat) : f1 * f2 = f2 * f1 := by
  simp [Nat.mul_comm]

-- Property 2: Deduction confidence is product f1 * f2 * c1 * c2
-- Concrete: f1=0.9, f2=0.9, c1=0.9, c2=0.9 → c_out = 0.6561
example : 9 * 9 * 9 * 9 = 6561 := by decide

-- Property 3: Confidence is bounded by frequency
-- c_out = f1 * f2 * c1 * c2 <= f1 * f2 (when c1, c2 <= 1)
example : 6561 < 81 * 100 := by decide

-- Property 4: If either frequency is 0, output frequency is 0
-- (negative evidence propagates transitively)
theorem ded_freq_zero (f2 c1 c2 : Nat) : 0 * f2 * c1 * c2 = 0 := by simp

-- Property 5: If either frequency is 0, output confidence is 0
-- Patrick confirmed 2026-04-09: ensures disconfirmed links zero out downstream
theorem ded_conf_zero_f1 (f2 c1 c2 : Nat) : 0 * f2 * c1 * c2 = 0 := by simp
theorem ded_conf_zero_f2 (f1 c1 c2 : Nat) : f1 * 0 * c1 * c2 = 0 := by simp

-- Property 6: Confidence decreases with each deduction step
-- 2-step: c_2 = f1 * f2 * c1 * c2, ratio = f1*f2 (G974)
example : 81 * 81 = 6561 := by decide

-- Property 7: Path independence of frequency
theorem ded_freq_path_indep (f1 f2 : Nat) : f1 * f2 = f2 * f1 := by
  simp [Nat.mul_comm]

end NALDeduction
