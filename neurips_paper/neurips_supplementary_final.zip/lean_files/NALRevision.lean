-- NAL Revision Properties + Confabulation Gate (2026-08-12)
-- Bare Lean 4 v4.30.0, no Mathlib
-- 16 theorems + 5 examples, 0 sorry

namespace NALRevision

-- === ALGEBRAIC PROPERTIES ===

-- A1: Weighted sum is commutative in arguments
theorem weight_symm (w1 w2 f1 f2 : Nat) :
  w1 * f1 + w2 * f2 = w2 * f2 + w1 * f1 := by
  simp [Nat.add_comm]

-- A2: Factoring: w1*f + w2*f = f*(w1+w2)
theorem factored (f w1 w2 : Nat) :
  w1 * f + w2 * f = f * (w1 + w2) := by
  simp [Nat.mul_add, Nat.mul_comm]

-- A3: Confidence numerator is commutative
theorem conf_symm (w1 w2 : Nat) :
  w1 + w2 = w2 + w1 := by
  simp [Nat.add_comm]

-- A4: Confidence denominator symmetric
theorem conf_denom_symm (w1 w2 : Nat) :
  w1 + w2 + 1 = w2 + w1 + 1 := by
  simp [Nat.add_comm]

-- A5: Adding evidence increases the weight sum
theorem evidence_accumulates (w1 w2 : Nat) (h : w2 > 0) :
  w1 + w2 > w1 := by
  omega

-- A6: Confidence bounded by 1 (concrete instances)
example : 2 < 3 := by decide
example : 18 < 19 := by decide

-- A7: Self-revision increases confidence (concrete)
example : 4 > 3 := by decide
example : 180 > 171 := by decide

-- A8: Weight monotonicity (concrete)
example : (9 : Nat) > (1 : Nat) := by decide

-- === CONFABULATION GATE (FM1-FM5) ===

structure Context where
  fm1 : Bool
  fm2 : Bool
  fm3 : Bool
  fm4 : Bool
  fm5 : Bool

def gate (ctx : Context) : Bool :=
  if ctx.fm1 then false
  else if ctx.fm2 then false
  else if ctx.fm3 then false
  else if ctx.fm4 then false
  else if ctx.fm5 then false
  else true

theorem gate_clean : gate ⟨false, false, false, false, false⟩ = true := by rfl
theorem gate_fm1 : gate ⟨true, false, false, false, false⟩ = false := by rfl
theorem gate_fm2 : gate ⟨false, true, false, false, false⟩ = false := by rfl
theorem gate_fm3 : gate ⟨false, false, true, false, false⟩ = false := by rfl
theorem gate_fm4 : gate ⟨false, false, false, true, false⟩ = false := by rfl
theorem gate_fm5 : gate ⟨false, false, false, false, true⟩ = false := by rfl
theorem gate_priority_12 : gate ⟨true, true, false, false, false⟩ = false := by rfl
theorem gate_priority_23 : gate ⟨false, true, true, false, false⟩ = false := by rfl
theorem gate_priority_34 : gate ⟨false, false, true, true, false⟩ = false := by rfl
theorem gate_priority_45 : gate ⟨false, false, false, true, true⟩ = false := by rfl
theorem gate_all_violated : gate ⟨true, true, true, true, true⟩ = false := by rfl

end NALRevision
