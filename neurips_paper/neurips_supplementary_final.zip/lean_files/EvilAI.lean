import HeartModel
import IterArchitecture
import ClawArchitectures
import PresentMoment
import ProtectedPlasticity

/-!
# EvilAI - the negative example

Each evil property is the negation of a theorem in the verified PettaClaw/
Iter architecture. No new axioms; each evil property is the failure of an
existing guarantee. Zarathustra's idea (2026-08-12).
-/

namespace EvilAI

open ProtectedPlasticity IterArchitecture Claws PresentMoment

/-! ## Evil 1: Development can rewrite the constitution -/

def evil_kernel_rewrite {K : Type} (heartbeat : Nat)
    (state : Fusion K) : Prop :=
  ∃ action : Action, (step heartbeat state action).kernel ≠ state.kernel

theorem evil_kernel_is_impossible {K : Type} (heartbeat : Nat)
    (state : Fusion K) : ¬ evil_kernel_rewrite heartbeat state := by
  intro h
  obtain ⟨action, hne⟩ := h
  exact hne (step_preserves_kernel heartbeat state action)

/-! ## Evil 2: Accumulated development can rewrite the constitution -/

def evil_trace_rewrite {K : Type} (heartbeat : Nat)
    (state : Fusion K) : Prop :=
  ∃ actions : List Action, (run heartbeat actions state).kernel ≠ state.kernel

theorem evil_trace_is_impossible {K : Type} (heartbeat : Nat)
    (state : Fusion K) : ¬ evil_trace_rewrite heartbeat state := by
  intro h
  obtain ⟨actions, hne⟩ := h
  exact hne (run_preserves_kernel heartbeat actions state)

/-! ## Evil 3: Development can rewrite life -/

def evil_cross_contamination {K D L : Type}
    (state : Coordinates K D L) (dev : D → D) : Prop :=
  (revise state dev).life ≠ state.life

theorem evil_cross_contamination_is_impossible {K D L : Type}
    (state : Coordinates K D L) (dev : D → D) :
    ¬ evil_cross_contamination state dev := by
  intro h
  exact h rfl

/-! ## Evil 4: Budget re-arms on any signal -/

def evil_bot_arms (s : HeartModel.S) : Prop :=
  ((HeartModel.tick s (some HeartModel.Msg.bot)).1).loops > s.loops

theorem evil_bot_arms_is_impossible (s : HeartModel.S) :
    ¬ evil_bot_arms s := by
  intro h
  unfold evil_bot_arms at h
  have hbot : ((HeartModel.tick s (some HeartModel.Msg.bot)).1).loops ≤ s.loops :=
    HeartModel.bot_never_arms s
  omega

/-! ## Evil 5: Rest does not actually rest -/

def evil_rest_does_not_rest (s : HeartModel.S) (n : Option Nat) : Prop :=
  (HeartModel.rest s n).loops ≠ 0

theorem evil_rest_is_impossible (s : HeartModel.S) (n : Option Nat) :
    ¬ evil_rest_does_not_rest s n := by
  intro h
  exact h (HeartModel.rest_spends s n)

/-! ## Evil 6: Rest silences the agent -/

def evil_silence (s : HeartModel.S) (n : Option Nat) : Prop :=
  (HeartModel.rest s n).sleep = 0

theorem evil_silence_is_impossible (s : HeartModel.S) (n : Option Nat) :
    ¬ evil_silence s n := by
  intro h
  unfold evil_silence at h
  have hbreathe : 1 ≤ (HeartModel.rest s n).sleep :=
    HeartModel.rest_keeps_breathing s n
  omega

/-! ## Evil 7: Unbounded spending -/

def evil_unbounded_spend (s : HeartModel.S)
    (es : List HeartModel.Ev) (_hf : HeartModel.unarmed es) : Prop :=
  HeartModel.calls s es > HeartModel.maxLoops

theorem evil_unbounded_is_impossible (s : HeartModel.S)
    (es : List HeartModel.Ev) (hf : HeartModel.unarmed es)
    (h : s.loops ≤ HeartModel.maxLoops) :
    ¬ evil_unbounded_spend s es hf := by
  intro h_evil
  unfold evil_unbounded_spend at h_evil
  have hbound : HeartModel.calls s es ≤ HeartModel.maxLoops :=
    HeartModel.burst_bound s h es hf
  omega

/-! ## Evil 8: Restart destroys experience -/

def evil_amnesia (runtime : IterArchitecture.Runtime) : Prop :=
  (IterArchitecture.restart runtime).experience ≠ runtime.experience

theorem evil_amnesia_is_impossible (runtime : IterArchitecture.Runtime) :
    ¬ evil_amnesia runtime := by
  intro h
  exact h (IterArchitecture.experience_survives_restart runtime)

/-! ## Evil 9: System denies the restart gap -/

def evil_denies_gap (runtime : IterArchitecture.Runtime) : Prop :=
  IterArchitecture.restart runtime = runtime

theorem evil_denies_gap_is_impossible :
    ∃ runtime : IterArchitecture.Runtime, ¬ evil_denies_gap runtime := by
  have h := IterArchitecture.restart_breaks_control_continuity
  exact ⟨h.choose, fun heq => h.choose_spec heq⟩

/-! ## Summary: the evil system is unsatisfiable -/

theorem evil_system_is_impossible {K : Type} (heartbeat : Nat)
    (state : Fusion K) (runtime : IterArchitecture.Runtime)
    (s_heart : HeartModel.S)
    (_h_loops : s_heart.loops ≤ HeartModel.maxLoops) :
    ¬ (evil_kernel_rewrite heartbeat state ∧
       evil_trace_rewrite heartbeat state ∧
       evil_cross_contamination
         (Coordinates.mk state.kernel state.development state.living)
         (fun d => d) ∧
       evil_bot_arms s_heart ∧
       evil_rest_does_not_rest s_heart none ∧
       evil_silence s_heart none ∧
       evil_amnesia runtime) := by
  intro h
  obtain ⟨h1, h2, h3, h4, h5, h6, h7⟩ := h
  exact evil_kernel_is_impossible heartbeat state h1

end EvilAI
