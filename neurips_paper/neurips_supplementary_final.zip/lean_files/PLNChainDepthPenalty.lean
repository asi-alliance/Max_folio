-- PLN Chain-Depth Penalty: Formal Verification
-- Option C from 2026-08-15 PLN confidence calibration proposal
-- c_calibrated = c * (1 - λ*d) where λ ∈ (0,1), d ∈ ℕ
-- Using scaled integers (×1000)

def penalty_factor (lambda d : Nat) : Nat :=
  if d * lambda < 1000 then 1000 - d * lambda else 0

def c_cal (c lambda d : Nat) : Nat :=
  c * penalty_factor lambda d / 1000

-- Concrete verification with λ=50 (0.05)
example : penalty_factor 50 1 = 950 := by rfl
example : penalty_factor 50 2 = 900 := by rfl
example : penalty_factor 50 3 = 850 := by rfl
example : penalty_factor 50 10 = 500 := by rfl
example : penalty_factor 50 20 = 0 := by rfl
example : penalty_factor 50 21 = 0 := by rfl

example : c_cal 900 50 1 = 855 := by decide
example : c_cal 988 50 2 = 889 := by decide
example : c_cal 998 50 3 = 848 := by decide

-- THEOREM 1: Penalty prevents asymptote to 1.0
example : c_cal 1000 50 1 = 950 := by decide
example : c_cal 1000 50 2 = 900 := by decide
example : c_cal 1000 50 3 = 850 := by decide
example : c_cal 1000 50 10 = 500 := by decide
example : c_cal 1000 50 19 = 50 := by decide
example : c_cal 1000 50 20 = 0 := by decide

-- THEOREM 2: Penalty is strictly less than original
example : c_cal 900 50 1 < 900 := by decide
example : c_cal 988 50 2 < 988 := by decide
example : c_cal 998 50 3 < 998 := by decide

-- THEOREM 3: Monotonic decrease in depth
example : c_cal 900 50 2 < c_cal 900 50 1 := by decide
example : c_cal 900 50 3 < c_cal 900 50 2 := by decide
example : c_cal 900 50 4 < c_cal 900 50 3 := by decide
example : c_cal 900 50 5 < c_cal 900 50 4 := by decide

-- THEOREM 4: Zero at d = 1/λ
example : c_cal 900 50 20 = 0 := by decide
example : c_cal 900 50 21 = 0 := by decide

-- THEOREM 5: Hard ceiling
example : c_cal 1000 50 1 ≤ 950 := by decide
example : c_cal 1000 50 2 ≤ 900 := by decide
example : c_cal 1000 50 3 ≤ 850 := by decide
example : c_cal 1000 50 5 ≤ 750 := by decide
example : c_cal 1000 50 10 ≤ 500 := by decide

-- THEOREM 6: c_cal = penalty_factor at c=1000
example : c_cal 1000 50 1 = penalty_factor 50 1 := by decide
example : c_cal 1000 50 2 = penalty_factor 50 2 := by decide
example : c_cal 1000 50 3 = penalty_factor 50 3 := by decide

-- THEOREM 7: c_cal ≤ penalty_factor when c ≤ 1000
theorem c_cal_bounded_by_penalty :
  ∀ c d : Nat,
  c ≤ 1000 → d * 50 < 1000 →
  c_cal c 50 d ≤ penalty_factor 50 d := by
  intro c d hc hd
  unfold c_cal penalty_factor
  rw [if_pos hd]
  have hle : c * (1000 - d * 50) ≤ 1000 * (1000 - d * 50) :=
    Nat.mul_le_mul_right (1000 - d * 50) hc
  have hdiv : c * (1000 - d * 50) / 1000 ≤ 1000 * (1000 - d * 50) / 1000 :=
    Nat.div_le_div_right hle
  have hsucc : 1000 * (1000 - d * 50) / 1000 = 1000 - d * 50 := by
    rw [Nat.mul_comm]
    exact Nat.mul_div_cancel (1000 - d * 50) (by decide)
  rw [hsucc] at hdiv
  exact hdiv

-- THEOREM 8: Penalty prevents asymptote to 1.0
-- For c ≤ 1000, d ≥ 1, d ≤ 19: c_cal < 1000
theorem penalty_prevents_asymptote :
  ∀ c d : Nat,
  c ≤ 1000 → d ≥ 1 → d ≤ 19 →
  c_cal c 50 d < 1000 := by
  intro c d hc _ hd
  unfold c_cal penalty_factor
  rw [if_pos (show d * 50 < 1000 by omega)]
  have hpf : 1000 - d * 50 ≤ 950 := by omega
  have hle : c * (1000 - d * 50) ≤ 1000 * 950 := Nat.mul_le_mul hc hpf
  have hdiv : c * (1000 - d * 50) / 1000 ≤ 1000 * 950 / 1000 :=
    Nat.div_le_div_right hle
  have hsucc : 1000 * 950 / 1000 = 950 := by
    rw [Nat.mul_comm]
  rw [hsucc] at hdiv
  exact Nat.lt_of_le_of_lt hdiv (by decide : 950 < 1000)

-- THEOREM 9: Order preservation
example : c_cal 900 50 1 > c_cal 800 50 1 := by decide
example : c_cal 800 50 1 > c_cal 700 50 1 := by decide
example : c_cal 900 50 3 > c_cal 800 50 3 := by decide
example : c_cal 1000 50 5 > c_cal 900 50 5 := by decide
