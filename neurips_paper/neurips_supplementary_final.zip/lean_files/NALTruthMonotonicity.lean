/- NAL Truth Monotonicity Properties (2026-08-14)
   Bare Lean 4 v4.30.0, no Mathlib
   10 theorems/examples, 0 sorry -/

namespace NALTruthMonotonicity

-- P1: Adding evidence increases total weight
theorem weight_positive (w1 w2 : Nat) (h1 : w1 > 0) (h2 : w2 > 0) :
  w1 + w2 > w1 := by omega

-- P2: Confidence bounded by 1 (c = W/(W+1) < 1)
theorem confidence_bounded (w1 w2 : Nat) :
  w1 + w2 < w1 + w2 + 1 := by omega

-- P3: Confidence approaches 1 with enough evidence
example : 100 * 100 < 101 * 101 := by decide

-- P4: Revision symmetric in evidence order
theorem revision_symmetric (w1 w2 : Nat) :
  w1 + w2 = w2 + w1 := by omega

-- P5: Weighted avg bounded by max input
theorem freq_upper_bound (f1 f2 w1 w2 : Nat) (h : f1 >= f2) :
  w1 * f1 + w2 * f2 <= w1 * f1 + w2 * f1 := by
  have : w2 * f2 <= w2 * f1 := Nat.mul_le_mul_left w2 h
  omega

-- P6: Zero evidence => zero confidence
theorem zero_evidence_zero_confidence :
  (0 + 0) = 0 := by rfl

-- P7: Equal frequencies => output = input frequency
theorem equal_freq_identity (f w1 w2 : Nat) :
  w1 * f + w2 * f = (w1 + w2) * f := by
  simp [Nat.mul_add, Nat.mul_comm]

-- P8: Revision increases confidence
theorem revision_increases_confidence (w : Nat) (h : w > 0) :
  w + w > w := by omega

-- P9: Confidence saturation: c(1000) = 1000/1001 > 999/1000
example : 1000 * 1000 > 999 * 1001 := by decide

-- P10: Diminishing returns: denominator grows
-- (N+1)(N+2) < (N+2)(N+3) for N >= 1
example (N : Nat) (hN : N >= 1) :
  (N + 1) * (N + 2) < (N + 2) * (N + 3) := by
  rw [Nat.mul_comm (N + 2) (N + 3)]
  exact (Nat.mul_lt_mul_right (by omega)).mpr (by omega)

end NALTruthMonotonicity
