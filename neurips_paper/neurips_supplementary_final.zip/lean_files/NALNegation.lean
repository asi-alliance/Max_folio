-- NAL Negation Properties Formal Verification (2026-08-13)
-- Bare Lean 4 v4.30.0, no Mathlib
-- 8 examples, 0 sorry
-- Proves NAL negation properties: f_out = 1 - f_in, c_out = c_in (confidence preserved)

namespace NALNegation

-- PROPERTY 1: Negation flips frequency: f_out = 1 - f_in
example : 1000 - 900 = 100 := by decide
example : 1000 - 100 = 900 := by decide
example : 1000 - 500 = 500 := by decide

-- PROPERTY 2: Negation preserves confidence: c_out = c_in
example : 900 = 900 := by decide
example : 500 = 500 := by decide

-- PROPERTY 3: Double negation = identity (f restored, c preserved)
example : 1000 - (1000 - 900) = 900 := by decide
example : 1000 - (1000 - 500) = 500 := by decide

-- PROPERTY 4: Negation of certain true = certain false
example : 1000 - 1000 = 0 := by decide

-- PROPERTY 5: Negation of certain false = certain true
example : 1000 - 0 = 1000 := by decide

-- PROPERTY 6: Negation of uncertain (f=0.5) = uncertain (f=0.5)
example : 1000 - 500 = 500 := by decide

-- PROPERTY 7: Complementarity: f + (1-f) = 1
example : 100 + 900 = 1000 := by decide
example : 500 + 500 = 1000 := by decide

end NALNegation
